<?php
$conn = new mysqli("127.0.0.1","root","","saltel_crud");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
     if(isset($_GET["id"])){
        $id = $_GET["id"];
        
        $sele  = $conn->query("SELECT * FROM crud WHERE id = $id");
        while($row = mysqli_fetch_assoc($sele)){
        $name = $row["username"];
        $password = $row["password"];
        $email = $row["email"];
     }
    }
    ?>
       <?php
   if(isset($_POST["sub"])){
    $n = $_POST["username"];
    $p = $_POST["password"];
    $e = $_POST["email"];

    $update = $conn->query("UPDATE crud SET username = '$n' , password = '$p' , email = '$e' WHERE id = $id");
    if($update){
        echo "data updated";
        header("location:read.php");
    }
    else{
        echo "failed";
    }
   }
       ?>
    <form action="" method="post">
    <label for="">Username</label><br>
        <input type="text" name="username" value = "<?php echo $name; ?>"><br>
        <label for="">Password</label><br>
        <input type="password" name="password" value = "<?php echo $password; ?>"><br>
        <label for="">Email</label><br>
        <input type="email" name="email" value = "<?php echo $email; ?>"><br>
        <button type="submit" name="sub">update</button>
    </form>
    
</body>
</html>