<?php
$conn = new mysqli("127.0.0.1","root","","saltel_crud");
?>
<?php
if(isset($_GET["id"])){
    $id = $_GET["id"];

    $delet = $conn->query("DELETE FROM crud WHERE id = $id");
    if($delet){
        header("location:read.php");
    }
    else{
        echo "failed";
    }
}
?>