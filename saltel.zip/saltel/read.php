<?php
$conn = new mysqli("127.0.0.1","root","","saltel_crud");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table{
            width: 700px;
        }
        table td a{
            text-decoration: none;
            color: white;
            border-radius: 3px;
            margin-left: 20px;
        }
    </style>
</head>
<body>
    <table border = "1">
        <thead>
        <tr>
            <th>Id</th>
            <th>Username</th>
            <th>Password</th>
            <th>Email</th>
            <th>Delete</th>
            <th>Update</th>
        </tr>
        </thead>
        <tbody>
    <?php
  $selet = $conn->query("SELECT * FROM crud");
  while($row = mysqli_fetch_assoc($selet)):
    ?>
        <tr>
            <td><?php echo $row["id"]?></td>
            <td><?php echo $row["username"];?></td>
            <td><?php echo $row["password"];?></td>
            <td><?php echo $row["email"];?></td>
            <td><a href="delete.php?id=<?php echo $row["id"] ?>" style="background-color: blue;">delete</a></td>
            <td><a href="update.php?id=<?php echo $row["id"] ?>" style="background-color: red;">update</a></td>
        </tr>
        </tbody>
        <?php
    endwhile;
    ?>
    </table>
    <form action="" method="post">   
    <button type="submit" name="subm">Back</button>
    <?php
    if(isset($_POST["subm"])){
        header("location:create.php");
    }
    ?>
    </form>
</body>
</html>