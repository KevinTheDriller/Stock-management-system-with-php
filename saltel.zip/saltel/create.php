<?php
$conn = new mysqli("127.0.0.1","root","","saltel_crud")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        <label for="">Username</label><br>
        <input type="text" name="username"><br>
        <label for="">Password</label><br>
        <input type="password" name="password"><br>
        <label for="">Email</label><br>
        <input type="email" name="email"><br>
        <button type="submit" name="sub">Save</button>
    </form>
    <?php
    if(isset($_POST["sub"])){
        $name = $_POST["username"];
        $password = $_POST["password"];
        $email = $_POST["email"];
        
        if(empty($name) || empty($password) || empty($email)){
            echo "please enter full details";
            exit;
        }
        else{
            $sql = $conn->query("INSERT INTO crud (username,password,email) VALUES ('$name','$password','$email')");
            if($sql){
                echo "data inserted in mysql";
                header("location:read.php");
                exit;
            }
            else{
                echo "failed to insert";
                exit;
            }
        }
    }
    ?>
</body>
</html>